const help = (prefix) => { 
	return `

*▌║========[MENU]========*
➬ 
➬  *${prefix}ownermenu*
➬  *${prefix}adminmenu*
➬  *${prefix}funmenu*
➬  *${prefix}mediamenu*
➬  *${prefix}kerangmenu*
➬  *${prefix}makermenu*
➬  *${prefix}othermenu*
➬  *${prefix}animemenu*
➬  *${prefix}nsfwmenu*
➬  *${prefix}vipmenu*
➬ 
*▌║=======================*
➬ 
➬  *${prefix}listmenu*
➬ 
*▌║⊱⊲ ⃟ ⃟ ⃟ ⛨*
*➬ ${prefix}bugreport*
*➬ *  *${prefix}info*
*➬ ${prefix}owner*
➬ 
*▌║⊱⊲ ⃟ ⃟ ⃟ ⛨*
➬ 
*➬ ${prefix}request*
*➬ ${prefix}setprefix*
*➬ ${prefix}listblock*
➬ 
*▌║⊱⊲ ⃟ ⃟ ⃟ ⛨*
➬ 
*➬ ${prefix}iklan*
*➬ ${prefix}runtume*
*➬ ${prefix}rules*
*➬ ${prefix}tnc*
*➬ ${prefix}cekvip*
➬ 
*▌║⊱⊲ ⃟ ⃟ ⃟ ⛨*
➬ 
*➬ ${prefix}daftarvip*
*➬ ${prefix}addvip*
*➬ ${prefix}dellvip*
*➬ ${prefix}snk*
*➬ ${prefix}listpremium*
*➬ ${prefix}donate*
*➬ ${prefix}fitnah*
*➬ ${prefix}totaluser*
*➬ ${prefix}level*
*➬ ${prefix}leveling*
*➬ ${prefix}addbacot*
*➬ ${prefix}bacotlist*
*➬ ${prefix}resetbacot*
➬ 
*▌║======[ABBAS BOT]======*
`
}
exports.help = help
